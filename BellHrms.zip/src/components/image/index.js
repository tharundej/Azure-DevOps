export { default } from './image';
